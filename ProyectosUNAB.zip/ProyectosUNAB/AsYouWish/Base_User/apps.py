from django.apps import AppConfig


class BaseUserConfig(AppConfig):
    name = 'Base_User'
