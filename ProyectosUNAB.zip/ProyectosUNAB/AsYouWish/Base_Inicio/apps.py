from django.apps import AppConfig


class BaseInicioConfig(AppConfig):
    name = 'Base_Inicio'
