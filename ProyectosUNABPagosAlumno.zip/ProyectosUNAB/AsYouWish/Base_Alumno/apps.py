from django.apps import AppConfig


class BaseAlumnoConfig(AppConfig):
    name = 'Base_Alumno'
