from django.apps import AppConfig


class BaseProfesorConfig(AppConfig):
    name = 'Base_Profesor'
