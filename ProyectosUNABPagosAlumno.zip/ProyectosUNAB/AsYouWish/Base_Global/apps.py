from django.apps import AppConfig


class BaseGlobalConfig(AppConfig):
    name = 'Base_Global'
