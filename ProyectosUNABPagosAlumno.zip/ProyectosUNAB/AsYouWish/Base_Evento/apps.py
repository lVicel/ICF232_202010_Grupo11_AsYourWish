from django.apps import AppConfig


class BaseEventoConfig(AppConfig):
    name = 'Base_Evento'
