from django.apps import AppConfig


class BaseClaseConfig(AppConfig):
    name = 'Base_Clase'
