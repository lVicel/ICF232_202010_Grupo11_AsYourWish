from django.apps import AppConfig


class BaseLocalConfig(AppConfig):
    name = 'Base_Local'
